/* pytest-style Python test to validate one-time prefetch and offline marker behavior */
import os
import sys
import types
from types import SimpleNamespace
from pathlib import Path

import pytest

# tests run with CWD set to services/visual-rag-sidecar, so import main directly
import main


def test_prefetch_creates_marker_and_caches_path(monkeypatch, tmp_path):
    # Prepare clean state
    monkeypatch.chdir(tmp_path)

    # Point index dir to a temp path inside tmp_path
    tmp_index = tmp_path / "indices"
    tmp_index.mkdir()
    monkeypatch.setattr(main.config, "INDEX_DIR", tmp_index)

    # Ensure no marker exists initially
    marker = tmp_index / ".hf_hub_download_complete"
    cache_file = tmp_index / ".hf_cached_model_path"
    assert not marker.exists()
    assert not cache_file.exists()

    # Provide a fake HF token to allow prefetch path for gated models
    monkeypatch.setattr(main.config, "HF_TOKEN", "fake-token")

    # Mock snapshot_download to create a fake snapshot dir and return its path
    def fake_snapshot_download(repo_id, repo_type=None, token=None, cache_dir=None):
        # Create deterministic path under tmp_path to simulate hub cache
        model_dir = tmp_path / "hf_cache" / f"models--{repo_id.replace('/', '--')}" / "snapshots" / "snap123"
        model_dir.mkdir(parents=True, exist_ok=True)
        # Write a fake file to make it non-empty
        (model_dir / "config.json").write_text('{"fake":true}')
        return str(model_dir)

    monkeypatch.setattr(main, "snapshot_download", fake_snapshot_download)

    # Monkeypatch heavy operations: dependency checks and Byaldi loader
    monkeypatch.setattr(main, "check_dependencies", lambda: None)
    monkeypatch.setattr(main, "inject_colqwen3_support", lambda: None)

    class DummyModel:
        @classmethod
        def from_pretrained(cls, *args, **kwargs):
            return cls()

        def to(self, *args, **kwargs):
            return self

    # Inject dummy byaldi module so load_model's import succeeds
    ns = types.SimpleNamespace(RAGMultiModalModel=DummyModel)
    monkeypatch.setitem(sys.modules, 'byaldi', ns)

    # Ensure CONFIG model id is set to a TomoroAI id (gated path)
    monkeypatch.setattr(main.config, "MODEL_NAME", "TomoroAI/tomoro-ai-colqwen3-embed-4b-awq")

    # Run load_model which will call prefetch_and_cache_model (via our change)
    # Run synchronously (it's not async)
    try:
        main.load_model()
    except Exception as exc:
        pytest.fail(f"load_model raised: {exc}")

    # Assert marker & cached path written
    assert marker.exists(), "Expected .hf_hub_download_complete marker to be created"
    assert cache_file.exists(), "Expected .hf_cached_model_path to be created"

    cached_path = cache_file.read_text().strip()
    assert cached_path, "Cached model path should be non-empty"
    assert Path(cached_path).exists(), "Cached model path should exist"

    # Assert offline enforcement: HF_HUB_OFFLINE set and HF_TOKEN cleared
    assert os.environ.get("HF_HUB_OFFLINE") == "1"
    assert main.config.HF_TOKEN is None

    # Clean up state
    main.state.model = None
    main.state.model_loaded = False
    main.state.loading = False
