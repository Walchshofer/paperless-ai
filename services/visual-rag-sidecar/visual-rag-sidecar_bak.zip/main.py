"""
Visual RAG Sidecar Service - Production Detox Version
Optimized for RTX 3090 Ti (24GB) & TomoroAI ColQwen3-8B

Implements Dynamic Registry Injection for ColQwen3 support in Byaldi.
"""

import atexit
import asyncio
import base64
import functools
import io
import logging
import os
import signal
import traceback
import warnings
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, cast

# Download utilities
from huggingface_hub import snapshot_download  # type: ignore[import-untyped]

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

# -----------------------------------------------------------------------------
# Signal + Exit Diagnostics
# -----------------------------------------------------------------------------


def _signal_handler(signum: int, frame: Any) -> None:
    logger.warning("Signal received: %s; frame=%s", signum, frame)
    try:
        traceback.print_stack(frame)
    except Exception:
        logger.debug("Failed to print stack for frame")


for _sig in (
    signal.SIGTERM,
    signal.SIGINT,
    getattr(signal, "SIGHUP", None),
):
    if _sig is None:
        continue

    try:
        signal.signal(_sig, _signal_handler)
    except Exception:
        pass


def _atexit_hook():
    try:
        loaded = (
            state.model_loaded
            if "state" in globals()
            else "unknown"
        )
        logger.warning("Atexit: model_loaded=%s", loaded)
    except Exception:
        pass


atexit.register(_atexit_hook)

# -----------------------------------------------------------------------------
# Logging Configuration
# -----------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

logger = logging.getLogger("visual_rag")

warnings.filterwarnings("ignore", message=".*torch_dtype.*")
logging.getLogger("transformers").setLevel(logging.ERROR)
logging.getLogger("root").setLevel(logging.ERROR)

# -----------------------------------------------------------------------------
# Environment
# -----------------------------------------------------------------------------

os.environ["TOKENIZERS_PARALLELISM"] = "false"

hf_env = os.getenv("HF_HUB_OFFLINE")
if hf_env and hf_env.strip().lower() in {"1", "true", "yes"}:
    os.environ["HF_HUB_OFFLINE"] = "1"

logger.info(
    "HF_HUB_OFFLINE status: %s",
    os.getenv("HF_HUB_OFFLINE", "False"),
)

# If a marker file exists in the index directory, enforce offline mode
# and clear any HF_TOKEN from the runtime environment to prevent further
# network calls after initial model download.
try:
    marker = (
        Path(os.getenv("INDEX_DIR", "/data/indices"))
        / ".hf_hub_download_complete"
    )
    if marker.exists():
        os.environ["HF_HUB_OFFLINE"] = "1"
        if "HF_TOKEN" in os.environ:
            os.environ.pop("HF_TOKEN", None)
        logger.info(
            "Detected %s; enforcing HF_HUB_OFFLINE=1 "
            "and clearing HF_TOKEN",
            marker
        )
except Exception as exc:
    logger.warning("Failed to check HF hub download marker: %s", exc)

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------


class Config:
    MODEL_NAME = os.getenv(
        "VISUAL_RAG_MODEL",
        "TomoroAI/tomoro-ai-colqwen3-embed-4b-awq"
    )
    # Hugging Face token for private models
    HF_TOKEN = os.getenv("HF_TOKEN", None)
    INDEX_DIR = Path(os.getenv("INDEX_DIR", "/data/indices"))
    MEDIA_DIR = Path(os.getenv("MEDIA_DIR", "/media/paperless"))
    DEFAULT_INDEX_NAME = os.getenv(
        "VISUAL_RAG_INDEX_NAME",
        "paperless_visual",
    )
    STORE_COLLECTION = (
        os.getenv("STORE_COLLECTION", "false").lower() == "true"
    )
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "8001"))


config = Config()


class ServiceState:
    def __init__(self):
        self.model = None
        self.model_loaded = False
        self.loading = False
        self.index_loaded = False
        self.indexing_in_progress = False
        self.indexed_documents: Dict[str, Any] = {}
        self.last_error: Optional[str] = None


state = ServiceState()

# -----------------------------------------------------------------------------
# Pydantic Models
# -----------------------------------------------------------------------------


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    index_loaded: bool
    model_name: str
    indexed_docs_count: int
    flash_attn_available: bool = False
    flash_attn_version: Optional[str] = None


class IndexRequest(BaseModel):
    pdf_path: Optional[str] = None
    images: Optional[List[str]] = None
    doc_id: Optional[int] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class SearchRequest(BaseModel):
    query: Optional[str] = None
    query_image: Optional[str] = None
    k: int = Field(5, ge=1, le=50)
    include_base64: bool = False


class SearchResult(BaseModel):
    doc_id: Optional[int]
    page_num: int
    score: float
    metadata: Dict[str, Any]
    file_path: str
    base64: Optional[str] = None


class SearchResponse(BaseModel):
    query: str
    results: List[SearchResult]
    total_results: int

# -----------------------------------------------------------------------------
# Phase 1: Dependency Validation
# -----------------------------------------------------------------------------


def check_dependencies() -> None:
    """Validate required dependencies for ColQwen3.

    Raises:
        EnvironmentError: If critical dependencies missing
    """
    missing: List[str] = []
    install_commands: List[str] = []

    # Check transformers (with Qwen3-VL support)
    try:
        import transformers
        version = getattr(transformers, "__version__", "unknown")
        logger.info(f"✅ transformers {version}")
    except ImportError:
        missing.append("transformers")
        install_commands.append("pip install transformers>=4.46.0")

    # Check torch
    try:
        import torch
        version = getattr(torch, "__version__", "unknown")
        logger.info(f"✅ torch {version}")
    except ImportError:
        missing.append("torch")
        install_commands.append("pip install torch>=2.6.0")

    # Check qwen_vl_utils (CRITICAL for Qwen3 visual processing)
    try:
        import qwen_vl_utils  # noqa: F401  # type: ignore
        logger.info("✅ qwen_vl_utils available")
    except ImportError:
        logger.warning(
            "⚠️ qwen_vl_utils not available "
            "(optional but recommended for Qwen3-VL)"
        )
        # Not critical for embedding model, only for generative VL models

    # Check accelerate
    try:
        import accelerate  # noqa: F401  # type: ignore
        version = getattr(accelerate, "__version__", "unknown")
        logger.info(f"✅ accelerate {version}")
    except ImportError:
        missing.append("accelerate")
        install_commands.append("pip install accelerate")

    # Check flash-attn (prevents OOM on 1280 tokens)
    try:
        import flash_attn  # noqa: F401  # type: ignore
        version = getattr(flash_attn, "__version__", "unknown")
        logger.info(f"✅ flash-attn {version}")
    except ImportError:
        logger.warning(
            "⚠️ flash-attn not available "
            "(performance will be degraded)"
        )
        # Not critical but highly recommended

    if missing:
        error_msg = (
            f"Missing critical dependencies: "
            f"{', '.join(missing)}\n\n"
            f"Install with:\n" + "\n".join(install_commands)
        )
        raise EnvironmentError(error_msg)

    logger.info("✅ All critical dependencies validated")


# -----------------------------------------------------------------------------
# Phase 2: ColQwen3Shim Class
# -----------------------------------------------------------------------------


class ColQwen3Shim:
    """Production-ready shim for ColQwen3 models.

    Wraps Hugging Face AutoModel for Byaldi compatibility with
    TomoroAI ColQwen3 models. Ensures RTX 3090 Ti configuration
    and handles trust_remote_code for custom architectures.

    Key Features:
    - Inherits from torch.nn.Module for compatibility
    - Uses trust_remote_code=True (CRITICAL)
    - Configured with bfloat16 for memory efficiency
    - Uses flash_attention_2 to prevent OOM
    - Implements required Byaldi interface methods

    Usage:
        shim = ColQwen3Shim("TomoroAI/...")
        # Use as a standard Byaldi model
    """

    def __init__(self, model_name: str, device: str = "cuda"):
        """Initialize ColQwen3Shim with specified model.

        Args:
            model_name: Hugging Face model identifier
            device: Target device ("cuda", "cpu", or "auto")
        """
        import torch
        from transformers import AutoModel, AutoProcessor

        logger.info(f"🔧 ColQwen3Shim: Initializing {model_name}")

        # Store configuration
        self.model_name = model_name
        self._device = device

        # Prepare token for private/gated models
        token = config.HF_TOKEN if config.HF_TOKEN else None

        # Prefer cached local model path
        cached_path = read_cached_model_path()
        if cached_path and cached_path.exists():
            load_source = str(cached_path)
            local_files_only = True
            logger.info("Using local cached model at %s", load_source)
        else:
            load_source = model_name
            local_files_only = False
            logger.info(
                "No cached model found; "
                "attempting remote load for %s",
                model_name
            )

        # Load model with CRITICAL settings for TomoroAI ColQwen3
        try:
            logger.info(
                "Loading model with trust_remote_code=True from %s...",
                load_source
            )
            self.model = AutoModel.from_pretrained(  # type: ignore
                load_source,
                # CRITICAL: Allows TomoroAI custom architecture
                trust_remote_code=True,
                torch_dtype=torch.bfloat16,  # Memory efficiency
                # Device placement
                device_map=device if device != "auto" else "auto",
                # Prevents OOM on 1280 tokens
                attn_implementation="flash_attention_2",
                # Only send token for remote loads
                token=(token if not local_files_only else None),
                local_files_only=local_files_only,
            )
            logger.info("✅ Model loaded successfully")
        except Exception as exc:
            logger.error(
                "Failed to load model with flash_attention_2: %s",
                exc
            )
            # Fallback without flash attention
            logger.info("Retrying without flash_attention_2...")
            self.model = AutoModel.from_pretrained(  # type: ignore
                load_source,
                trust_remote_code=True,
                torch_dtype=torch.bfloat16,
                device_map=device if device != "auto" else "auto",
                token=(token if not local_files_only else None),
                local_files_only=local_files_only,
            )
            logger.warning(
                "⚠️ Model loaded without flash_attention_2 "
                "(may OOM on large inputs)"
            )

        # Load processor
        try:
            logger.info("Loading processor from %s...", load_source)
            self.processor = AutoProcessor.from_pretrained(  # type: ignore
                load_source,
                trust_remote_code=True,  # Also required for processor
                token=(token if not local_files_only else None),
                local_files_only=local_files_only,
            )
            logger.info("✅ Processor loaded successfully")
        except Exception as exc:
            logger.warning(f"Failed to load processor: {exc}")
            self.processor = None

        # Set model to evaluation mode for inference
        self.model.eval()  # type: ignore
        logger.info(f"✅ ColQwen3Shim initialized on device: {self._device}")

    def forward(self, *args: Any, **kwargs: Any) -> Any:
        """Forward pass delegation to wrapped model.

        Args:
            *args: Positional arguments passed to model
            **kwargs: Keyword arguments passed to model

        Returns:
            Model output (embeddings, logits, etc.)
        """
        return self.model(*args, **kwargs)  # type: ignore[misc]

    @property
    def device(self) -> Any:
        """Get the device where the model is located.

        Returns:
            torch.device: Model device
        """
        return next(self.model.parameters()).device  # type: ignore

    def to(self, *args: Any, **kwargs: Any) -> "ColQwen3Shim":
        """Move model to specified device/dtype.

        Args:
            *args: Positional arguments for torch.nn.Module.to()
            **kwargs: Keyword arguments for torch.nn.Module.to()

        Returns:
            self: For method chaining
        """
        self.model = self.model.to(*args, **kwargs)  # type: ignore
        return self

    def eval(self) -> "ColQwen3Shim":
        """Set model to evaluation mode.

        Returns:
            self: For method chaining
        """
        self.model.eval()  # type: ignore
        return self

    def save_pretrained(self, *args: Any, **kwargs: Any) -> None:
        """Stub to prevent errors if Byaldi tries to save.

        No-op implementation; doesn't save the shim wrapper.
        If needed, delegate to self.model.save_pretrained().

        Args:
            *args: Ignored
            **kwargs: Ignored
        """
        logger.debug("ColQwen3Shim.save_pretrained called (no-op)")
        # Optionally delegate to wrapped model:
        # self.model.save_pretrained(*args, **kwargs)


# -----------------------------------------------------------------------------
# Phase 3: Registry Injection
# -----------------------------------------------------------------------------


def inject_colqwen3_support() -> None:
    """Inject ColQwen3 support into Byaldi registry.

    Monkey-patches Byaldi's from_pretrained to intercept
    ColQwen3 model loading and use ColQwen3Shim.

    The patch:
    1. Captures the original from_pretrained method
    2. Creates patched version checking for "colqwen3"
    3. If ColQwen3: uses ColQwen3Shim
    4. Otherwise: delegates to original method
    5. Applies monkey patch with metadata preservation

    Allows Byaldi to work with ColQwen3 without changes.
    """
    try:
        from byaldi import RAGMultiModalModel  # type: ignore[import-untyped]

        logger.info(
            "🔧 Injecting ColQwen3 support into Byaldi registry..."
        )

        # Capture original method
        original_from_pretrained = cast(
            Callable[..., Any],
            RAGMultiModalModel.from_pretrained  # type: ignore[attr-defined]
        )

        @functools.wraps(original_from_pretrained)
        def patched_from_pretrained(
            pretrained_model_name_or_path: str,
            *args: Any,
            **kwargs: Any
        ) -> Any:
            """Patched from_pretrained supporting ColQwen3.

            Args:
                pretrained_model_name_or_path: Model ID or path
                *args: Additional positional arguments
                **kwargs: Additional keyword arguments

            Returns:
                RAGMultiModalModel instance (shim or original)
            """
            model_name_lower = pretrained_model_name_or_path.lower()

            # Check if this is a ColQwen3 model request
            if "colqwen3" in model_name_lower:
                logger.info(
                    "✅ ColQwen3 detected: %s",
                    pretrained_model_name_or_path
                )
                logger.info("Using ColQwen3Shim for model loading...")

                # Extract device from kwargs
                device = kwargs.get("device", "cuda")

                # Create ColQwen3Shim instance
                shim = ColQwen3Shim(
                    pretrained_model_name_or_path,
                    device=device
                )

                # Create RAGMultiModalModel instance manually
                # This bypasses Byaldi's internal model registry
                instance = object.__new__(RAGMultiModalModel)  # type: ignore

                # Hydrate the instance with required attributes
                instance.model = shim.model  # type: ignore[attr-defined]
                processor_val = cast(
                    Any,
                    shim.processor  # type: ignore[attr-defined]
                    if hasattr(shim, 'processor') else None
                )
                instance.processor = processor_val  # type: ignore
                instance.device = device  # type: ignore
                model_name_val = pretrained_model_name_or_path
                instance.model_name = model_name_val  # type: ignore

                # Initialize any other required attributes
                # (These may vary based on Byaldi version)
                if not hasattr(instance, 'index'):  # type: ignore[arg-type]
                    instance.index = None  # type: ignore[attr-defined]
                if not hasattr(instance, 'doc_ids'):  # type: ignore[arg-type]
                    instance.doc_ids = []  # type: ignore[attr-defined]

                logger.info(
                    "✅ RAGMultiModalModel instance created "
                    "with ColQwen3Shim"
                )
                return instance  # type: ignore[return-value]
            else:
                # Not a ColQwen3 model - delegate to original method
                logger.debug(
                    "Using original from_pretrained for: %s",
                    pretrained_model_name_or_path
                )
                return original_from_pretrained(  # type: ignore[return-value]
                    pretrained_model_name_or_path,
                    *args,
                    **kwargs
                )

        # Apply the monkey patch
        RAGMultiModalModel.from_pretrained = patched_from_pretrained
        logger.info(
            "✅ ColQwen3 support injected into Byaldi registry"
        )

    except ImportError as exc:
        logger.error(
            "Failed to inject ColQwen3 support: "
            "Byaldi not available (%s)",
            exc
        )
        raise
    except Exception as exc:
        logger.error("Failed to inject ColQwen3 support: %s", exc)
        raise


# -----------------------------------------------------------------------------
# Phase 4: Operational Validation
# -----------------------------------------------------------------------------


def validate_injection() -> bool:
    """Validate that ColQwen3 injection is working correctly.

    This function performs runtime validation to ensure:
    1. Model loading works with ColQwen3 identifier
    2. Device placement is correct
    3. Data type is correct (bfloat16)
    4. Basic operations can be performed

    Returns:
        bool: True if validation passed, False otherwise

    Note:
        This is a best-effort validation. It doesn't test actual indexing
        since that would require document data.
    """
    try:
        import torch  # noqa: F401  # type: ignore
        from byaldi import RAGMultiModalModel  # type: ignore

        logger.info("🔍 Validating ColQwen3 injection...")

        # Test model loading with a ColQwen3 identifier
        # We would use "test/colqwen3-validation" to test detection
        # logic without actually loading, but we skip that here

        # Check if our patched method is in place
        from_pretrained_method = cast(
            Any,
            RAGMultiModalModel.from_pretrained  # type: ignore[attr-defined]
        )
        if not hasattr(from_pretrained_method, '__wrapped__'):
            logger.warning("⚠️ from_pretrained doesn't appear to be wrapped")
            return False

        logger.info("✅ Registry injection appears to be in place")

        # Additional validation could include:
        # - Actually loading the real model (expensive)
        # - Testing a small indexing operation
        # - Verifying attention implementation

        return True

    except Exception as exc:
        logger.error(f"Validation failed: {exc}")
        return False


# -----------------------------------------------------------------------------
# Model Loading (Enhanced with Dynamic Registry Injection)
# -----------------------------------------------------------------------------


def read_cached_model_path() -> Optional[Path]:
    """Return cached local model path from initial download.

    The cached path file is stored at: ${INDEX_DIR}/.hf_cached_model_path
    """
    try:
        cache_file = config.INDEX_DIR / ".hf_cached_model_path"
        if cache_file.exists():
            path_text = cache_file.read_text().strip()
            if path_text:
                return Path(path_text)
    except Exception as exc:
        logger.warning("Could not read cached model path: %s", exc)
    return None


def mark_hf_hub_download_complete(
    cached_model_path: Optional[str] = None
) -> None:
    """Create marker for HF downloads complete.

    Persists cached model path, enforces offline mode, clears
    HF_TOKEN. Locks sidecar offline until operator removes.
    """
    try:
        marker = config.INDEX_DIR / ".hf_hub_download_complete"
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text("completed\n")

        if cached_model_path:
            cache_file = config.INDEX_DIR / ".hf_cached_model_path"
            cache_file.write_text(str(cached_model_path) + "\n")
            logger.info("Cached model path recorded to %s", cache_file)

        os.environ["HF_HUB_OFFLINE"] = "1"
        if "HF_TOKEN" in os.environ:
            os.environ.pop("HF_TOKEN", None)
        config.HF_TOKEN = None
        logger.info(
            "🔒 Created HF hub download complete marker at %s "
            "and enforced offline mode",
            marker
        )
    except Exception as exc:
        logger.warning("Failed to create HF hub download marker: %s", exc)


def prefetch_and_cache_model(model_id: str) -> Optional[str]:
    """On first startup, download model snapshot to HF cache.

    Persists reference so subsequent restarts run fully offline.

    Returns the local path when successful.
    """
    # If we already recorded a cached path, return it immediately
    cached = read_cached_model_path()
    if cached and cached.exists():
        logger.info("Using existing cached model at %s", cached)
        return str(cached)

    # If marker exists, expect cached path
    marker = config.INDEX_DIR / ".hf_hub_download_complete"
    if marker.exists():
        logger.warning(
            "Marker exists but no cached model path found; "
            "please check %s",
            config.INDEX_DIR
        )
        return None

    # If model is private (TomoroAI), ensure we have a token
    if model_id.lower().startswith("tomoroai/") and not config.HF_TOKEN:
        raise EnvironmentError(
            "Model appears to be gated (TomoroAI). "
            "Set HF_TOKEN in env so sidecar can download "
            "the model on first run."
        )

    # Perform the snapshot download to the huggingface cache location
    try:
        logger.info(
            "Downloading model snapshot for %s to local cache...",
            model_id
        )
        # Override cache dir via HUGGINGFACE_CACHE env
        cache_dir = os.getenv(
            "HUGGINGFACE_CACHE",
            "/root/.cache/huggingface"
        )
        snapshot_path = snapshot_download(
            repo_id=model_id,
            repo_type="model",
            token=config.HF_TOKEN,
            cache_dir=cache_dir
        )
        logger.info("✅ Model snapshot downloaded to %s", snapshot_path)

        # Persist marker + cached model path and enforce offline mode
        mark_hf_hub_download_complete(
            cached_model_path=str(snapshot_path)
        )
        return str(snapshot_path)
    except Exception as exc:
        logger.error(
            "Failed to download model snapshot for %s: %s",
            model_id,
            exc
        )
        raise


def load_model() -> None:
    """Enhanced loader with Dynamic Registry Injection.

    Phases:
    1. Dependency validation (check_dependencies)
    2. Registry injection (inject_colqwen3_support)
    3. Model loading via patched Byaldi
    4. Operational validation (validate_injection)

    Configuration:
    - Uses W4A16 quantization (AWQ native)
    - trust_remote_code=True for Tomoro's ColQwen3
    - attn_implementation=flash_attention_2 for RTX 3090 Ti
    """
    global state  # noqa: F824

    if state.loading:
        return

    state.loading = True

    try:
        import torch  # type: ignore
        from byaldi import RAGMultiModalModel  # type: ignore

        # Phase 1: Validate dependencies
        logger.info("=" * 80)
        logger.info("Phase 1: Dependency Validation")
        logger.info("=" * 80)
        try:
            check_dependencies()
        except EnvironmentError as exc:
            logger.error(f"Dependency validation failed: {exc}")
            state.last_error = str(exc)
            raise

        # Phase 2: Inject ColQwen3 support into Byaldi registry
        logger.info("=" * 80)
        logger.info("Phase 2: Registry Injection")
        logger.info("=" * 80)
        try:
            inject_colqwen3_support()
        except Exception as exc:
            logger.error(f"Registry injection failed: {exc}")
            state.last_error = str(exc)
            raise

        # Phase 3: Load model (now with ColQwen3 support)
        logger.info("=" * 80)
        logger.info("Phase 3: Model Loading")
        logger.info("=" * 80)

        # Prefer configured model name (env: VISUAL_RAG_MODEL)
        # for tests and runtime overrides
        MODEL_ID = config.MODEL_NAME

        logger.info(
            "🚀 Initializing model from configuration: %s",
            MODEL_ID
        )

        # Try to discover local snapshot if marker exists
        marker = config.INDEX_DIR / ".hf_hub_download_complete"
        cached_path_file = config.INDEX_DIR / ".hf_cached_model_path"
        if marker.exists() and not cached_path_file.exists():
            try:
                logger.info(
                    "Offline marker present but cached model path "
                    "missing; attempting to discover existing "
                    "snapshot in Hugging Face cache"
                )

                def discover_and_record_cached_model_path(
                    model_id: str
                ) -> Optional[str]:
                    # Derive hub dir name
                    safe_name = f"models--{model_id.replace('/', '--')}"
                    hub_base = Path(
                        os.getenv(
                            "HUGGINGFACE_CACHE",
                            "/root/.cache/huggingface"
                        )
                    ) / "hub"
                    candidate = None
                    try:
                        mdir = hub_base / safe_name
                        snaps_dir = mdir / "snapshots"
                        snaps = (
                            list(snaps_dir.glob("*"))
                            if snaps_dir.exists()
                            else []
                        )
                        if snaps:
                            candidate = str(snaps[-1])
                            cache_file = (
                                config.INDEX_DIR /
                                ".hf_cached_model_path"
                            )
                            cache_file.write_text(candidate + "\n")
                            logger.info(
                                "Discovered and recorded cached "
                                "model path: %s",
                                candidate
                            )
                            return candidate
                    except Exception as exc:
                        logger.warning(
                            "Discovery of cached model failed: %s", exc
                        )
                    return None

                discovered = discover_and_record_cached_model_path(
                    MODEL_ID
                )
                if discovered:
                    logger.info(
                        "✅ Cached model path discovered: %s",
                        discovered
                    )
                else:
                    logger.info("No local snapshot found for %s", MODEL_ID)
            except Exception as exc:
                logger.warning(
                    "Failed to discover cached snapshot: %s",
                    exc
                )

        # If first startup (no marker), prefetch the model
        if not marker.exists():
            try:
                logger.info(
                    "No offline marker found; prefetching model "
                    "for initial download"
                )
                prefetch_and_cache_model(MODEL_ID)
            except Exception as exc:
                logger.error("Model prefetch failed: %s", exc)
                state.last_error = str(exc)
                raise

        # CRITICAL CONFIGURATION:
        # 1. load_in_4bit=False
        #    (Prevents double-quantization conflict with AWQ)
        # 2. trust_remote_code=True
        #    (Required for ColQwen3 architecture definition)
        # 3. attn_implementation="flash_attention_2"
        #    (Mandatory for speed on RTX 3090 Ti)

        # Get typed reference to from_pretrained
        from_pretrained_fn = cast(
            Callable[..., Any],
            RAGMultiModalModel.from_pretrained  # type: ignore[attr-defined]
        )

        try:
            # Preferred invocation (when signature accepts it)
            state.model = from_pretrained_fn(
                MODEL_ID,
                device="cuda",
                trust_remote_code=True,
                load_in_4bit=False,
                attn_implementation="flash_attention_2",
            )
        except TypeError as exc:
            # Fall back to safer, minimal call when wrapper's
            # from_pretrained doesn't accept optional kwargs
            logger.warning(
                "from_pretrained signature mismatch: %s. "
                "Retrying with reduced args",
                exc,
            )
            try:
                state.model = from_pretrained_fn(
                    MODEL_ID,
                    device="cuda"
                )
            except ValueError as exc2:
                logger.warning(
                    "Model name unsupported (%s); "
                    "trying ColPali fallback",
                    exc2
                )
                fallback_model_id = "colpali/colpali-base"
                state.model = from_pretrained_fn(
                    fallback_model_id,
                    device="cuda"
                )
        except ValueError as exc:
            # Older Byaldi/ColPali may not recognize ColQwen3 name
            # Try ColPali fallback to verify index API
            logger.warning(
                "Model name unsupported (%s); trying ColPali fallback",
                exc
            )
            fallback_model_id = "colpali/colpali-base"
            state.model = from_pretrained_fn(
                fallback_model_id,
                device="cuda"
            )

        # Post-load: set attention and cast to bfloat16
        try:
            model_ref: Any = state.model
            if hasattr(model_ref, "set_attn_implementation"):
                try:
                    model_ref.set_attn_implementation("flash_attention_2")
                except Exception:
                    logger.debug(
                        "Could not set attn implementation via setter"
                    )
        except Exception:
            pass

        try:
            state.model = state.model.to(torch.bfloat16)  # type: ignore
        except Exception:
            logger.warning(
                "Could not cast model to bfloat16; "
                "proceeding with default dtype"
            )

        state.model_loaded = True
        # Persist offline marker & clear tokens
        try:
            mark_hf_hub_download_complete()
        except Exception as exc:
            logger.warning(
                "Could not mark HF download complete: %s",
                exc
            )
        logger.info("✅ SUCCESS: Model loaded. Expect VRAM usage ~3.5GB.")

        # Phase 4: Validate injection
        logger.info("=" * 80)
        logger.info("Phase 4: Operational Validation")
        logger.info("=" * 80)
        validation_passed = validate_injection()
        if validation_passed:
            logger.info("✅ All phases completed successfully")
            logger.info(
                "✅ ColQwen3 Dynamic Registry Injection: ACTIVE"
            )
        else:
            logger.warning(
                "⚠️ Validation warnings detected "
                "(model may still work)"
            )

    except Exception as exc:
        state.last_error = str(exc)
        logger.exception("Model load failed")
        logger.error("=" * 80)
        logger.error("FATAL: Model initialization failed")
        logger.error(f"Error: {exc}")
        logger.error("=" * 80)

    finally:
        state.loading = False


def ensure_model_loaded() -> None:
    """Raise an HTTPException if the model is not yet fully loaded.

    Keeps a small, clear interface for endpoints to assert readiness.
    """
    """Raise an HTTPException if the model is not yet fully loaded.

    Keeps a small, clear interface for endpoints to assert readiness.
    """
    if not state.model_loaded:
        raise HTTPException(
            status_code=503,
            detail="Model is still loading...",
        )

# -----------------------------------------------------------------------------
# FastAPI Application
# -----------------------------------------------------------------------------


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        import flash_attn  # noqa: F401  # type: ignore

        os.environ["FLASH_ATTN_VERSION"] = getattr(
            flash_attn,
            "__version__",
            "active",
        )
    except Exception:
        os.environ["FLASH_ATTN_VERSION"] = "none"

    config.INDEX_DIR.mkdir(parents=True, exist_ok=True)
    asyncio.create_task(asyncio.to_thread(load_model))
    yield
    state.model = None


app = FastAPI(
    title="Visual RAG Detox",
    lifespan=lifespan,
)


# -----------------------------------------------------------------------------
# Indexing Endpoint (Decoupled Indexer)
# -----------------------------------------------------------------------------

@app.post("/index")
async def index_document(request: IndexRequest):
    """Index a PDF path or a list of base64 images.

    Uses `store_collection_with_index=True` so base64 images
    remain available for retrieval.
    """
    ensure_model_loaded()

    if not request.pdf_path and not request.images:
        raise HTTPException(
            status_code=400,
            detail="Either 'pdf_path' or 'images' must be provided",
        )

    input_path = request.pdf_path if request.pdf_path else request.images

    try:
        # The wrapper now manages storage internally.
        # store_collection_with_index=True keeps base64 images available
        # for fast retrieval when requested.
        state.model.index(  # type: ignore
            input_path=input_path,
            index_name=config.DEFAULT_INDEX_NAME,
            store_collection_with_index=True,
            overwrite=True,
        )

        state.index_loaded = True
        # Best-effort: update indexed_documents count if model returned
        # a summary. Some index implementations return metadata.
        doc_count = getattr(state.model, "indexed_count", None)
        if doc_count is not None:
            state.indexed_documents = {"count": doc_count}

        return {"status": "indexed", "index_name": config.DEFAULT_INDEX_NAME}

    except Exception as exc:
        state.last_error = str(exc)
        logger.exception("Indexing failed")
        raise HTTPException(status_code=500, detail="Indexing failed")


@app.get("/health", response_model=HealthResponse)
async def health_check():
    return HealthResponse(
        status="healthy" if state.model_loaded else "loading",
        model_loaded=state.model_loaded,
        index_loaded=state.index_loaded,
        model_name=config.MODEL_NAME,
        indexed_docs_count=len(state.indexed_documents),
        flash_attn_available=(
            os.environ.get("FLASH_ATTN_VERSION") != "none"
        ),
        flash_attn_version=os.environ.get("FLASH_ATTN_VERSION"),
    )


@app.get("/vram")
async def vram_check() -> Dict[str, Any]:
    """Report GPU memory usage (best-effort).

    Returns not-available when CUDA or torch isn't present.
    """
    try:
        import torch  # type: ignore

        if (
            not getattr(torch, "cuda", None)
            or not torch.cuda.is_available()
        ):
            return {"available": False, "detail": "CUDA not available"}

        allocated: int = torch.cuda.memory_allocated()
        reserved: int = torch.cuda.memory_reserved()
        max_alloc: Optional[int] = None
        try:
            max_alloc = torch.cuda.max_memory_allocated()
        except Exception:
            max_alloc = None

        return {
            "available": True,
            "allocated_bytes": int(allocated),
            "reserved_bytes": int(reserved),
            "allocated_mb": float(allocated) / (1024 ** 2),
            "reserved_mb": float(reserved) / (1024 ** 2),
            "max_allocated_bytes": (
                int(max_alloc) if max_alloc is not None else None
            ),
            "note": (
                "If allocated/reserved > 10GB, "
                "AWQ kernel likely failed to load"
            ),
        }
    except Exception as exc:
        return {"available": False, "detail": str(exc)}


@app.post("/search", response_model=SearchResponse)
async def search(request: SearchRequest):
    """Search the visual index.

    Accepts either a text `query` or a base64-encoded `query_image`.
    Returns a `SearchResponse` with formatted results or raises HTTP
    errors for invalid input or when the model is not ready.
    """
    ensure_model_loaded()

    query: Any = request.query

    if request.query_image:
        try:
            # Lazy import Pillow to avoid import-time failures
            try:
                import PIL.Image as PilImage  # type: ignore
            except Exception:
                raise HTTPException(
                    status_code=500,
                    detail="Pillow is not installed in the container",
                )

            image_bytes = base64.b64decode(request.query_image)
            img: Any = PilImage.open(io.BytesIO(image_bytes))  # type: ignore
            query = cast(Any, img.convert("RGB"))  # type: ignore
        except HTTPException:
            raise
        except Exception as exc:
            detail_msg = f"Invalid query_image: {exc}"
            raise HTTPException(status_code=400, detail=detail_msg)

    if query is None:
        raise HTTPException(
            status_code=400,
            detail="Either 'query' or 'query_image' must be provided",
        )

    if not hasattr(state.model, "search") or not callable(
        getattr(state.model, "search")
    ):
        raise HTTPException(
            status_code=503,
            detail="Model is not yet ready to perform searches",
        )

    try:
        results = state.model.search(query, k=request.k)  # type: ignore
    except Exception as exc:
        state.last_error = str(exc)
        logger.exception("Model search failed")
        raise HTTPException(status_code=500, detail="Model search failed")

    formatted: List[SearchResult] = []
    for r in results:  # type: ignore[union-attr]
        result_dict = cast(Dict[str, Any], r)
        meta = cast(Dict[str, Any], result_dict.get("metadata", {}))
        doc_id_val = cast(Optional[int], meta.get("paperless_doc_id"))
        page_val = cast(int, result_dict.get("page_num", 1))
        score_val = cast(float, result_dict.get("score", 0.0))
        path_val = cast(str, meta.get("source_path", ""))
        base64_val = cast(
            Optional[str],
            result_dict.get("base64") if request.include_base64 else None
        )
        formatted.append(
            SearchResult(
                doc_id=doc_id_val,
                page_num=int(page_val),
                score=float(score_val),
                metadata=meta,
                file_path=str(path_val),
                base64=base64_val,
            )
        )

    return SearchResponse(
        query=str(request.query),
        results=formatted,
        total_results=len(formatted),
    )


if __name__ == "__main__":
    import uvicorn

    logger.info(
        "Starting Uvicorn on %s:%d",
        config.HOST,
        config.PORT,
    )
    uvicorn.run(
        "main:app",
        host=config.HOST,
        port=config.PORT,
    )
